/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import java.util.ArrayList;
import java.util.Comparator;

public class FastCollinearPoints {

    private Point[] sortedPoints;
    private LineSegment[] lineSegments;

    public FastCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException(
                "argument to BruteCollinearPoints constructor is null");
        this.sortedPoints = new Point[points.length];
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) throw new IllegalArgumentException(
                    "argument to Fast constructor contains null point");
            this.sortedPoints[i] = points[i];
        }
        sortPoints();
    }

    // the number of line segments
    public int numberOfSegments() {
        if (lineSegments == null) {
            generateSegments();
        }
        return lineSegments.length;
    }

    // the line segments
    public LineSegment[] segments() {
        if (lineSegments == null) {
            generateSegments();
        }
        return copySegments();
    }

    private void generateSegments() {
        int start = 0;
        Point[] points = new Point[sortedPoints.length];
        Point[] aux = new Point[sortedPoints.length];
        Point[][] listAndAux = new Point[2][sortedPoints.length];
        for (int i = 0; i < points.length; i++) {
            points[i] = sortedPoints[i];
            aux[i] = points[i];
        }
        listAndAux[0] = points;
        listAndAux[1] = aux;
        ArrayList<LineSegment> seenPoints = new ArrayList<LineSegment>();
        while (start < points.length) {
            sortAfterWithSlope(listAndAux, sortedPoints[start]);
            points = listAndAux[0];
            int len = 2;
            double checkSlope = Double.NEGATIVE_INFINITY;
            Point me = sortedPoints[start];
            Point low = me;
            Point high = null;
            for (int i = 0; i < points.length; i++) {
                if (me.slopeTo(points[i]) == checkSlope) {
                    len++;
                    high = points[i];
                }
                else {
                    if (len >= 4 && me.compareTo(low) <= 0) {
                        seenPoints.add(new LineSegment(me, high));
                    }
                    checkSlope = me.slopeTo(points[i]);
                    low = points[i];
                    len = 2;
                }
                if (i == points.length - 1 && me.slopeTo(points[i]) == checkSlope
                        && me.compareTo(low) <= 0) {
                    if (len >= 4) {
                        seenPoints.add(new LineSegment(me, high));
                    }
                }
            }
            start++;
        }
        lineSegments = seenPoints.toArray(new LineSegment[0]);
    }

    private void sortPoints() {
        Point[][] listAndAux = new Point[][] { sortedPoints, new Point[sortedPoints.length] };
        sortT(listAndAux, Point::compareTo);
        sortedPoints = listAndAux[0];
        for (int i = 1; i < sortedPoints.length; i++) {
            if (sortedPoints[i].compareTo(sortedPoints[i - 1]) == 0) {
                throw new IllegalArgumentException("duplicate points");
            }
        }
    }

    private <T> void sortT(T[][] listAndAux, Comparator<T> comparator) {
        T[] current = listAndAux[0];
        T[] auxilary = listAndAux[1];
        T[] temp;
        int starLength = 2;
        //
        while (starLength / 2 <= current.length) {
            for (int i = 0; i < current.length; i += starLength) {
                int low = i;
                int middle = i + starLength / 2;
                int right = middle;
                int end = (middle + starLength / 2) >= current.length ? current.length :
                          middle + starLength / 2;
                for (int j = low; j < end; j++) {
                    if (low >= middle) {
                        auxilary[j] = current[right];
                        right++;
                        continue;
                    }
                    else if (right >= end) {
                        auxilary[j] = current[low];
                        low++;
                        continue;
                    }
                    int c = comparator.compare(current[low], current[right]);
                    if (c <= 0) {
                        auxilary[j] = current[low];
                        low++;
                    }
                    else {
                        auxilary[j] = current[right];
                        right++;
                    }
                }
            }
            starLength *= 2;
            temp = current;
            current = auxilary;
            auxilary = temp;
        }
        // 0-32
        listAndAux[0] = current;
        listAndAux[1] = auxilary;
    }

    private void sortAfterWithSlope(Point[][] listAndAux, Point with) {
        Comparator<Point> so = with.slopeOrder();
        Comparator<Point> slopeOrder = (a, b) -> {
            int sslope = so.compare(a, b);
            if (sslope != 0) return sslope;
            else return a.compareTo(b);
        };
        sortT(listAndAux, slopeOrder);
    }

    private LineSegment[] copySegments() {
        LineSegment[] copy = new LineSegment[lineSegments.length];
        for (int i = 0; i < lineSegments.length; i++) {
            copy[i] = lineSegments[i];
        }
        return copy;
    }
}