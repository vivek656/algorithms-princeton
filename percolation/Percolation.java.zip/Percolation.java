/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    WeightedQuickUnionUF uf;
    int n;
    boolean[] sites;
    int totalOpenSites = 0;

    private int indx(int row, int col) {
        return (row - 1) * n + (col);
    }

    private boolean getSiteAt(int idx) {
        return sites[idx - 1];
    }

    private void setSiteAt(int idx, boolean valu) {
        boolean curr = getSiteAt(idx);
        sites[idx - 1] = valu;
        if (valu != curr) {
            if (valu) totalOpenSites++;
            else totalOpenSites--;
        }
    }

    private boolean isOpen(int idx) {
        return getSiteAt(idx);
    }

    private void setSiteOpen(int idx) {
        setSiteAt(idx, true);
    }

    private int topSpotIdx;
    private int bottomSpotIdx;

    private int checkOrGet(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n) throw new IllegalArgumentException();
        return indx(row, col);
    }

    private Integer getorNullOrElseWithTopAndBottom(int row, int col, int orElse) {
        if (row == 0) return topSpotIdx;
        if (row == n + 1) return bottomSpotIdx;
        if (row < 1 || row > n || col < 1 || col > n) return orElse;
        return indx(row, col);
    }

    private int[] getNeighbour(int row, int col) {
        return new int[] {
                getorNullOrElseWithTopAndBottom(row - 1, col, -1),
                getorNullOrElseWithTopAndBottom(row, col + 1, -1),
                getorNullOrElseWithTopAndBottom(row + 1, col, -1),
                getorNullOrElseWithTopAndBottom(row, col - 1, -1)
        };
    }

    private void union(int idx1, int idx2) {
        uf.union(idx1 - 1, idx2 - 1);
    }

    private boolean isConnected(int idx1, int idx2) {
        int uf1 = uf.find(idx1 - 1);
        int uf2 = uf.find(idx2 - 1);
        return uf1 == uf2;
    }

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        uf = new WeightedQuickUnionUF((n * n) + 2);
        sites = new boolean[(n * n) + 2];
        sites[(n * n)] = true;
        sites[(n * n) + 1] = true;
        topSpotIdx = (n * n + 1);
        bottomSpotIdx = (n * n + 2);
        this.n = n;
    }


    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        int idx = checkOrGet(row, col);
        int[] neighbours = getNeighbour(row, col);
        setSiteOpen(idx);
        for (int i : neighbours) {
            if (i != -1 && isOpen(i)) {
                union(idx, i);
            }
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        return isOpen(checkOrGet(row, col));
    }

    // is the site (row, col) full?
    // 5

    // 1 2
    // 3 4

    // 6
    // 2 1
    public boolean isFull(int row, int col) {
        return isConnected(checkOrGet(row, col), topSpotIdx);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return totalOpenSites;
    }

    // does the system percolate?
    public boolean percolates() {
        for (int i = 1; i <= n; i++) {
            if (isFull(n, i)) return true;
        }
        return false;
    }

    // test client (optional)
    public static void main(String[] args) {

    }
}
